// $( document ).ready(function(){
// 	$ ("#card").mouseenter(function(){
// 		$( this ).hide('slow')});
// 	$("#card").mouseleave(function(){
// 		$( this ).fadeIn('slow')
// 	});
		
	
// });